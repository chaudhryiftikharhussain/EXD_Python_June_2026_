from django.db import models

class ParkingFloor(models.Model):
    floor_number = models.IntegerField(unique=True)
    PARKING_FLOOR_STATUS = {
        "available": "Available",
        "not_available": "Not Available",
    }
    status = models.CharField(max_length=20, choices=PARKING_FLOOR_STATUS, default="available")

    def __str__(self):
        return f"Floor# {self.floor_number} ({self.status})"


class ParkingSlot(models.Model):
    floor = models.ForeignKey(ParkingFloor, on_delete=models.CASCADE)
    slot_number = models.CharField(max_length=20, unique=True)
    PARKING_SLOTS_STATUS = {
        "available": "Available",
        "occupied": "Occupied",
        "reserved": "Reserved",
    }
    status = models.CharField(max_length=20, choices=PARKING_SLOTS_STATUS, default="available")

    def __str__(self):
        return f"Slot # {self.slot_number} ({self.status}), Floor: {self.floor}"
