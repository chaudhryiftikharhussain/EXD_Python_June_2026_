from django.contrib import admin

from core.models import ParkingFloor, ParkingSlot


class ParkingFloorAdmin(admin.ModelAdmin):
    list_display = ("floor_number", "status")
    list_filter = ("status", )
admin.site.register(ParkingFloor, ParkingFloorAdmin)
# admin.site.register(ParkingFloor)



admin.site.register(ParkingSlot)


